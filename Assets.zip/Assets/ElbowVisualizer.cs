using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class ElbowVisualizer : MonoBehaviour
{
    public string fileName = "NORMAL_trackedUser.csv";

    public readonly int LEFT = 0;
    public readonly int RIGHT = 1;

    public int preview = 0;

    public class PositionInfo
    {
        public float time;

        public Vector3 headPosition;
        public Vector3[] shoulderPositions = new Vector3[2];
        public Vector3[] controllerPositions = new Vector3[2];
        public Vector3[] elbowPositions = new Vector3[2];
    }

    public List<PositionInfo> allPositions = null;
    public float shoulderOffset = 0.1f;
    public float seatOffset = 0.1f;
    public Vector3 fakeSeatPosition;
    public float lArmLength;
    public float rArmLength;


    void Start()
    {
        allPositions = new List<PositionInfo>();

        string[] fileLines = File.ReadAllLines(Path.Combine(Application.streamingAssetsPath, fileName));

        float[] armLengths = new float[2];
        for (int i = 1; i < fileLines.Length; i++)
        {
            FillPositionFromFileLine(fileLines[i], out PositionInfo position);

            if (i == 1) {
                armLengths[LEFT] = CalculateArmLength(position.shoulderPositions[LEFT], position.controllerPositions[LEFT]);
                lArmLength = armLengths[LEFT];
                //print ('Left Arm D' + armLengths[LEFT]);
                armLengths[RIGHT] = CalculateArmLength(position.shoulderPositions[RIGHT], position.controllerPositions[RIGHT]);
                rArmLength = armLengths[RIGHT];
                //print ('Right Arm D' + armLengths[RIGHT]);

                fakeSeatPosition = position.headPosition - 
                    (Vector3.up * (armLengths[LEFT] + armLengths[RIGHT]) * 0.2f) + 
                        (Vector3.up * seatOffset);
            }

            CalculateElbow(ref position, LEFT, armLengths[LEFT]);
            CalculateElbow(ref position, RIGHT, armLengths[RIGHT]);

            allPositions.Add(position);
        }
    }

    void FillPositionFromFileLine(string fileLine, out PositionInfo position)
    {
        string[] splitString = fileLine.Split(',');

        //0     1           2           3           4           5           6           7
        //Time,	HeadPos.X,	HeadPos.Y,	HeadPos.Z,	HeadRot.X,	HeadRot.Y,	HeadRot.Z,	HeadRot.W,	

        //8         9           10          11          12          13          14          15
        //LCPos.X,	LCPos.Y,	LCPos.Z,	LCRot.X,	LCRot.Y,	LCRot.Z,	LCRot.W,	RCPos.X,	 

        //16        17          18          19          20          21          22          23
        //RCPos.Y,	RCPos.Z,	RCRot.X,	RCRot.Y,	RCRot.Z,	RCRot.W,	LSPos.X,	LSPos.Y,	

        //24        25          26          27          28              29      
        //LSPos.Z,	RSPos.X,	RSPos.Y,	RSPos.Z,	HoldingObject,	ObjectName

        position = new PositionInfo();

        position.time = float.Parse(splitString[0]);

        position.headPosition = new Vector3(
            position.time = float.Parse(splitString[1]),
            position.time = float.Parse(splitString[2]),
            position.time = float.Parse(splitString[3])
        );

        position.controllerPositions[LEFT] = new Vector3(
            position.time = float.Parse(splitString[8]),
            position.time = float.Parse(splitString[9]),
            position.time = float.Parse(splitString[10])
        );

        position.controllerPositions[RIGHT] = new Vector3(
            position.time = float.Parse(splitString[15]),
            position.time = float.Parse(splitString[16]),
            position.time = float.Parse(splitString[17])
        );

        position.shoulderPositions[LEFT] = new Vector3(
            position.time = float.Parse(splitString[22]),
            position.time = float.Parse(splitString[23]),
            position.time = float.Parse(splitString[24])
        ) + Vector3.up * shoulderOffset;

        position.shoulderPositions[RIGHT] = new Vector3(
            position.time = float.Parse(splitString[25]),
            position.time = float.Parse(splitString[26]),
            position.time = float.Parse(splitString[27])
        ) + Vector3.up * shoulderOffset;
    }

    float CalculateArmLength(Vector3 handPosition, Vector3 shoulderPosition)
    {
       return (shoulderPosition - handPosition).magnitude;
       
    }

    void CalculateElbow(ref PositionInfo position, int side, float lengthOfArm)
    {
        Vector3 centerOfArm = (position.shoulderPositions[side] + position.controllerPositions[side]) * 0.5f;

        if ((position.shoulderPositions[side] - position.controllerPositions[side]).magnitude > lengthOfArm * 0.99f)
        {
            position.elbowPositions[side] = centerOfArm;
            return;
        }

        float halfArmLengthSqrd = Mathf.Pow(lengthOfArm * 0.5f, 2.0f);
        float halfDistanceSqrd = Mathf.Pow((position.shoulderPositions[side] - position.controllerPositions[side]).magnitude * 0.5f, 2.0f);

        float elbowHeight = Mathf.Sqrt(halfArmLengthSqrd - halfDistanceSqrd);

        Vector3 shoulderToController = (position.controllerPositions[side] - position.shoulderPositions[side]).normalized;

        position.elbowPositions[side] = centerOfArm + (Vector3.Cross(shoulderToController, Vector3.up) * elbowHeight * (side == 0 ? 1.0f : -1.0f));
    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnDrawGizmos()
    {
        if (allPositions == null) return;

        int index = Mathf.Min(allPositions.Count - 1, preview);

        PositionInfo currentPosition = allPositions[index];

        Gizmos.color = Color.yellow;
        Gizmos.DrawSphere(currentPosition.headPosition, 0.2f);

        Gizmos.color = Color.red;
        Gizmos.DrawSphere(currentPosition.shoulderPositions[LEFT], 0.1f);
        Gizmos.DrawSphere(currentPosition.controllerPositions[LEFT], 0.075f);
        Gizmos.DrawSphere(currentPosition.elbowPositions[LEFT], 0.05f);
        Gizmos.DrawLine(currentPosition.shoulderPositions[LEFT], currentPosition.elbowPositions[LEFT]);
        Gizmos.DrawLine(currentPosition.controllerPositions[LEFT], currentPosition.elbowPositions[LEFT]);

        Gizmos.color = Color.blue;
        Gizmos.DrawSphere(currentPosition.shoulderPositions[RIGHT], 0.1f);
        Gizmos.DrawSphere(currentPosition.controllerPositions[RIGHT], 0.075f);
        Gizmos.DrawSphere(currentPosition.elbowPositions[RIGHT], 0.05f);
        Gizmos.DrawLine(currentPosition.shoulderPositions[RIGHT], currentPosition.elbowPositions[RIGHT]);
        Gizmos.DrawLine(currentPosition.controllerPositions[RIGHT], currentPosition.elbowPositions[RIGHT]);

        Gizmos.color = Color.green;
        Gizmos.DrawSphere(fakeSeatPosition, 0.1f);


        Vector3 plane = (currentPosition.shoulderPositions[LEFT] - currentPosition.shoulderPositions[RIGHT]).normalized;

        Gizmos.DrawLine(fakeSeatPosition, Vector3.ProjectOnPlane(currentPosition.shoulderPositions[LEFT], plane));
        Gizmos.DrawLine(Vector3.ProjectOnPlane(currentPosition.elbowPositions[LEFT], plane),
                        Vector3.ProjectOnPlane(currentPosition.shoulderPositions[LEFT], plane));

    }
}
